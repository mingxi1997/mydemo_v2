module.exports = {
    publicPath: "./"   // 相对路径
};
