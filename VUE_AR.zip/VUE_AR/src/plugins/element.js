import ElementPlus from 'element-plus'
import '../element-variables.scss'

export default (app) => {
  app.use(ElementPlus)
}
