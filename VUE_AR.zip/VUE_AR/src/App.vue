<template>
  <img src="./assets/logo.png">
  <div>
 
    <el-button type="primary">el-button</el-button>
    <el-button type="warning">Warning</el-button>
  </div>
  <div class="dropdown">
      <router-link to="/" tag="ul" class="dropbtn">下拉菜单</router-link>
  <div class="dropdown-content">
    <router-link to="/" tag="li">Home </router-link>
    <router-link to="/about" tag="li">About </router-link>
  </div>

  <router-view />

  <h1 v-text="msg"></h1>

  </div>



</template>

<script>

export default {
  name: 'App',
  components: {
    // HelloWorld
  },
  data() {
        return {
          msg:"you can see",
        }
      },
  methods:{
        query_data:

        function(){setInterval(()=>{
          this.$http.get('http://127.0.0.1:5000/todo/api/v1.0/tasks/'+Math.random()).then((res) => {
            this.msg=res.data['id']
            })},3000)},
        
        // function(){setInterval(()=>{
        //   this.$http.get('http://127.0.0.1:5000/test').then((res) => {
        //     this.msg=res.data[0]
        //     // console.log(this.msg[0])
        //     })},3000)},

        
        
    },

  created() {
          this.query_data();
        },
  

}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
/* 下拉按钮样式 */
.dropbtn {
    background-color: #4CAF50;
    color: white;
    padding: 16px;
    font-size: 16px;
    border: none;
    cursor: pointer;
}

/* 容器 <div> - 需要定位下拉内容 */
.dropdown {
    position: relative;
    display: inline-block;
}

/* 下拉内容 (默认隐藏) */
.dropdown-content {
    display: none;
    position: absolute;
    background-color: #f9f9f9;
    min-width: 160px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
}

/* 下拉菜单的链接 */
.dropdown-content a {
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
}

/* 鼠标移上去后修改下拉菜单链接颜色 */
.dropdown-content a:hover {background-color: #f1f1f1}

/* 在鼠标移上去后显示下拉菜单 */
.dropdown:hover .dropdown-content {
    display: block;
}

/* 当下拉内容显示后修改下拉按钮的背景颜色 */
.dropdown:hover .dropbtn {
    background-color: #3e8e41;
}
</style>
